This is a starter kit for dapp development.

There are a lot of useful comments for you to search for extra info and a lot of gaps that you have to fill out
in the json files.

This is my first attempt at something like this, i hope you find it useful.

